#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include "AsciiArtTool.h"

#define BUFFER_SIZE 256
#define END_OF_STRING '\0'


/**
 * @brief create a RLEList and insert the content from the in_stream into it/
 * 
 * @param in_stream input file
 * @return RLEList of the file cintent
 */
RLEList asciiArtRead(FILE *in_stream)
{
    if (!in_stream)
    {
        return NULL;
    }
    int curentLetter = 0;
    RLEList list = RLEListCreate();
    if(list == NULL){
        return NULL;
    }
    RLEListResult result = RLE_LIST_SUCCESS;
    curentLetter = fgetc(in_stream);
    while (curentLetter != EOF)
    {
        result = RLEListAppend(list, (char)curentLetter);
        if (result != RLE_LIST_SUCCESS)
        {
            RLEListDestroy(list);
            return NULL;
        }
        curentLetter = fgetc(in_stream);
    }
    return list;
}


/**
 * @brief gets RLEList and a File, prints the list in the filr
 * 
 * @param list RLElist
 * @param out_stream output File
 * @return RLEListResult 
 */
RLEListResult asciiArtPrintEncoded(RLEList list, FILE *out_stream)
{
    if ((!list) || (!out_stream))
    {
        return RLE_LIST_NULL_ARGUMENT;
    }

    RLEListResult r = RLE_LIST_SUCCESS;
    RLEListResult *result = &r;
    char *str = RLEListExportToString(list, result);
    if (*result != RLE_LIST_SUCCESS)
    {
        return *result;
    }
    if (!str)
    {
        return RLE_LIST_ERROR;
    }

    char *ptr = str;
    fprintf(out_stream, "%s", str);
    free(ptr);

    return RLE_LIST_SUCCESS;
}


/**
 * @brief gets list and a file, prints the image that the list represent in encoded mod
 * 
 * @param list RLEList
 * @param out_stream output file
 * @return RLEListResult 
 */
RLEListResult asciiArtPrint(RLEList list, FILE *out_stream)
{ // Galor - new
    if ((!list) || (!out_stream))
    {
        return RLE_LIST_NULL_ARGUMENT;
    }

    int listSize = RLEListSize(list);
    if(listSize<1)
    {
        return RLE_LIST_ERROR;
    }
   
    char *str = malloc(listSize+1);
    if(str == NULL) {
        return RLE_LIST_NULL_ARGUMENT;
    }
    char *strFirst = str;
    RLEListResult r = RLE_LIST_SUCCESS;
    RLEListResult *result = &r;
    for( int i =0; i<listSize; i++)
    {
        int letter = RLEListGet(list, i, result);
        if(*result != RLE_LIST_SUCCESS){
            free(strFirst);
            return *result;
        }
        str[i] = letter;
    }
    str[listSize] = END_OF_STRING;
    fprintf(out_stream, "%s", str);
    free(strFirst);
    return RLE_LIST_SUCCESS;
}




