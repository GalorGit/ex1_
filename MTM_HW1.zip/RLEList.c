#include "RLEList.h"
#include <stdio.h>
#include <stdlib.h>

#define NEW_LINE '\n'
#define END_OF_A_STRING '\0'

struct RLEList_t
{
    // TODO: implement
    char m_letter;
    int m_length;
    struct RLEList_t *m_next;
};

// implement the function s here

// ------------------------ ALTERNATIVES --------------------------------//
int countNumbersInNum(int num);
void NodeToDelete(RLEList list);
void removeOneChar(RLEList list);
int putListInStr(RLEList list, char *str);

void NodeToDelete(RLEList list)
{
    RLEList trash = list;
    list = list->m_next;
    free(trash);
}

// ------------------------------------------------------------------------//

// after Galor’s changes - 23.4.22 . 12:53

// implement the functions here

/**
 * RLEListCreate: Allocates a new empty RLE list.
 *
 * The function allocates and returns a new RLEList struct containing a list with no characters.
 * Note that the user must free the returned list using RLEListDestroy() once it is no longer needed.
 *
 * @return
 *  NULL if allocations failed.
 *  A new RLEList in case of success.
 */
RLEList RLEListCreate()
{
    RLEList ptr = malloc(sizeof(*ptr));
    if (!ptr)
    {
        return NULL;
    }
    ptr->m_letter = END_OF_A_STRING;
    ptr->m_length = 0;
    ptr->m_next = NULL;
    return ptr;
}

/**
 * RLEListDestroy: Deallocates an existing RLE list.
 *
 * @param list - RLE list to be deallocated. If RLE list is NULL nothing will be done
 */
void RLEListDestroy(RLEList list)
{
    if (list == NULL)
    {
        return;
    }
    while (list)
    {
        NodeToDelete(list);
        list = list->m_next;
    }
}

/**
 *   RLEListAppend: add a specified character at the end of the list.
 *
 * @param list - The RLE list for which to add the character
 * @param value - The character which needs to be added.
 * @return
 *  RLE_LIST_NULL_ARGUMENT if a NULL was sent as one of the parameters
 *  RLE_LIST_OUT_OF_MEMORY if an allocation failed
 *  RLE_LIST_SUCCESS if the character has been inserted successfully
 */
RLEListResult RLEListAppend(RLEList list, char value)
{
    if (list == NULL)
    {
        return RLE_LIST_NULL_ARGUMENT;
    }
    if (value == END_OF_A_STRING)
    {
        return RLE_LIST_ERROR;
    }

    RLEList ptr = list;
    if (list->m_length == 0)
    {
        ptr->m_letter = value;
        ptr->m_length = 1;
        return RLE_LIST_SUCCESS;
    }
    else
    {
        while (ptr->m_next != NULL)
        {
            ptr = ptr->m_next;
        }

        if (ptr->m_letter == value)
        {
            ptr->m_length++;
            return RLE_LIST_SUCCESS;
        }
        else
        {
            ptr->m_next = RLEListCreate();
            if (ptr->m_next == NULL)
            {
                return RLE_LIST_OUT_OF_MEMORY;
            }

            ptr->m_next->m_letter = value;
            ptr->m_next->m_length = 1;

            return RLE_LIST_SUCCESS;
        }
    }
}

/**
 * RLEListSize: Returns the total number of characters in an RLE list.
 * @param list - The RLE list whose size is requested
 * @return
 *   -1 if a NULL pointer was sent.
 *   Otherwise the total number of characters in the list.
 */
int RLEListSize(RLEList list)
{
    if (!list)
    {
        return -1;
    }
    RLEList ptr = list;
    int length = 0;
    while (ptr)
    {
        length += ptr->m_length;
        ptr = ptr->m_next;
    }
    return length;
}

/**
 *   RLEListRemove: Removes a character found at a specified index in an RLE list.
 *
 * @param list - The RLE list to remove the character from.
 * @param index - The index at which the character to be removed is found.
 * @return
 *   RLE_LIST_NULL_ARGUMENT if a NULL was sent to the function.
 *   RLE_LIST_INDEX_OUT_OF_BOUNDS if given index is not withing the list's bounds.
 *   RLE_LIST_SUCCESS the character found at index has been removed successfully.
 */
RLEListResult RLEListRemove(RLEList list, int index)
{
    if (!list)
    {
        return RLE_LIST_NULL_ARGUMENT;
    }
    int fullSize = RLEListSize(list);
    if (fullSize <= index)
    {
        return RLE_LIST_INDEX_OUT_OF_BOUNDS;
    }
    int length = list->m_length;
    RLEList indexFinder = list;
    while (length < index)
    {
        if ((index - length) <= 1)
        {
            removeOneChar(list);
            return RLE_LIST_SUCCESS;
        }
        index -= length;
        indexFinder = indexFinder->m_next;
        length = indexFinder->m_length;
    }
    indexFinder->m_length -= 1;
    return RLE_LIST_SUCCESS;
}

void removeOneChar(RLEList list)
{
    RLEList ptr = list;
    ptr = ptr->m_next;
    if ((ptr->m_length) > 1)
    {
        ptr->m_length -= 1;
        return;
    }
    NodeToDelete(ptr);
    if ((list->m_letter) != (ptr->m_letter))
    {
        return;
    }
    int length = ptr->m_length;
    list->m_length += length;
    NodeToDelete(ptr);
    list->m_next = ptr;
    return;
}

/**
 *   RLEListGet: Returns the character found at a specified index in an RLE list.
 *
 * @param list - The RLE list to retrieve the character from.
 * @param index - The index at which the character to be retrieved is found.
 * @param result - Pointer to be used to store the result of the operation, if it is NULL, the result will not be saved.
 *  RLE_LIST_NULL_ARGUMENT if a NULL was sent to the function as list.
 *  RLE_LIST_INDEX_OUT_OF_BOUNDS if given index is not withing the list's bounds.
 *  LIST_SUCCESS the character found at index has been retrieved successfully.
 * @return
 *  0 if result is not RLE_LIST_SUCCESS.
 *  The character found at given index in case of success.
 */
char RLEListGet(RLEList list, int index, RLEListResult *result)
{
    if (list == NULL)
    {
        if (result != NULL)
        {
            *result = RLE_LIST_NULL_ARGUMENT;
        }
        return 0;
    }
    int listSize = RLEListSize(list);
    if ((index + 1)> listSize || listSize < 1)
    {
        if (result != NULL)
        {
            *result = RLE_LIST_INDEX_OUT_OF_BOUNDS;
        }
        return 0;
    }

    RLEList ptr = list, lastNode = list;
    int sum = 0;
    while ((sum < index+1) && (ptr != NULL))
    {
        sum += ptr->m_length;
        lastNode = ptr;
        ptr = ptr->m_next;
    }

    if (sum >= index+1)
    {
        if (result != NULL)
        {
            *result = RLE_LIST_SUCCESS;
        }
        return lastNode->m_letter;
    }

    if (ptr == NULL)
    {
        if (result != NULL)
        {
            *result = RLE_LIST_ERROR;
        }
        return 0;
    }
    return 0;
}

/**
 *   RLEListMap: Change the given RLE list's characters according to the received mapping function.
 *               This function replaces each character of the give RLE list with its mapped character.
 *
 * @param list - The RLE list to edit.
 * @param MapFunction - Pointer to a function of type MapFunction.
 * @return
 *  RLE_LIST_NULL_ARGUMENT if a NULL was sent as a paramater.
 *  LIST_SUCCESS if the mapping is done successfully.
 */
RLEListResult RLEListMap(RLEList list, MapFunction map_function)
{

    if (list == NULL)
    {
        return RLE_LIST_NULL_ARGUMENT;
    }
    if (map_function == NULL)
    {
        return RLE_LIST_ERROR;
    }
    RLEList ptr = list;
    while (ptr != NULL)
    {
        ptr->m_letter = map_function(ptr->m_letter);
        ptr = ptr->m_next;
    }
    return RLE_LIST_SUCCESS;
}

/**
 *   RLEListExportToString: Returns the characters found in an RLE list as a string.
 *
 * @param list - The RLE list to be exported as a string.
 * @param result - Pointer to be used to store the result of the operation, if it is NULL, the result will not be saved.
 *  RLE_LIST_NULL_ARGUMENT if a NULL was sent to the function as list.
 *  LIST_SUCCESS the RLE list has been successfuly exported as a string.
 * @return
 *  NULL if result is not RLE_LIST_SUCCESS.
 *  The string that corresponds to the received RLE list.
 */
char *RLEListExportToString(RLEList list, RLEListResult *result)
{
    if (list == NULL)
    {
        if (result != NULL)
        {
            *result = RLE_LIST_NULL_ARGUMENT;
        }
        return NULL;
    }
    if (list->m_length == 0)
    {
        if (result != NULL)
        {
            *result = RLE_LIST_ERROR;
        }
        return NULL;
    }
    int listSize = RLEListSize(list);
    if (listSize < 1)
    {
        if (result != NULL)
        {
            *result = RLE_LIST_ERROR;
        }
        return NULL;
    }
    char *str = malloc((listSize * 3) + 1);
    char *strFirst = str;
    if (str == NULL)
    {
        if (result != NULL)
        {
            *result = RLE_LIST_OUT_OF_MEMORY;
        }
        return NULL;
    }
    int size = putListInStr(list, str);
    char *tmpStr = malloc(size + 1);
    if (tmpStr == NULL)
    {
        if (result != NULL)
        {
            *result = RLE_LIST_OUT_OF_MEMORY;
        }
        free(strFirst);
        return NULL;
    }
    for (int i = 0; i < size; i++)
    {
        tmpStr[i] = strFirst[i];
    }
    tmpStr[size] = '\0';
    free(strFirst);

    if (result != NULL)
    {
        *result = RLE_LIST_SUCCESS;
    }
    return tmpStr;
}



/**
 * @brief puts the RLEList list into a string.
 * thr arry may be bigger than the string itself.
 *
 * @param list - RLEList list
 * @param str - char array to put the list in
 * @return thr size of the array
 */
int putListInStr(RLEList list, char *str)
{
    int size = 0;
    RLEList tmpStr = list;
    while (tmpStr != NULL)
    {
        *str = tmpStr->m_letter;
        if (tmpStr->m_length > 9)
        {
            int numbersCount = countNumbersInNum(tmpStr->m_length);
            int temp = tmpStr->m_length;

            for (int i = 0; i < numbersCount; i++)
            {
                *(str + numbersCount - i) = (char)((temp % 10) + 48);
                temp = temp / 10;
            }
            *(str + numbersCount + 1) = NEW_LINE;
            str += 2 + numbersCount;
            size += 2 + numbersCount;
        }
        else
        {
            *(str + 1) = (char)(tmpStr->m_length + 48);
            *(str + 2) = NEW_LINE;
            str += 3;
            size += 3;
        }
        tmpStr = tmpStr->m_next;
    }
    return size;
}

/**
 * @brief cheaks how many nubers there are in the number num
 *
 * @param num the number to check
 * @return int - how many nambers are in num
 */
int countNumbersInNum(int num)
{
    if (num == 0)
    {
        return 0;
    }
    return 1 + countNumbersInNum(num / 10);
}

