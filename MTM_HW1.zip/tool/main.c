
//#include "../RLEList.h"
#include "AsciiArtTool.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#define FLAG_INDEX 1
#define SOURCE_STREAM_INDEX 2
#define TRAGET_STREAM_INDEX 3
#define E_OR_I_INDEX 1
#define MAIN_FLAGS_COUNT 4
#define E 'e'
#define I 'i'
#define READ_FILE_FLAG "r"
#define WRITE_FILE_FLAG "w"
#define CHAR_SPACE ' '
#define CHAR_STRUDEL '@'

char invertLetter(char c);
void closeFiles(FILE *file1, FILE *file2);
int readAndPrintInvertedByMap(FILE *sourceFile, FILE *tragetFile, MapFunction map_Function);
int readAndPrintEncoded(FILE *sourceFile, FILE *tragetFile);

/**
 * @brief gets flag, source file, output file.
 * if the flag is 'e' - print in the output file the encoded source file image
 * if the flag is 'i' - print in the output file the inverted source file image
 *
 * @param argc
 * @param argv
 * @return int 0
 */
int main(int argc, char **argv)
{
    if (argc == MAIN_FLAGS_COUNT)
    {
        FILE *sourceFile = fopen(argv[SOURCE_STREAM_INDEX], READ_FILE_FLAG);
        FILE *tragetFile = fopen(argv[TRAGET_STREAM_INDEX], WRITE_FILE_FLAG);
        if (sourceFile == NULL || tragetFile == NULL)
        {
            if (tragetFile != NULL)
            {
                fclose(tragetFile);
                return 0;
            }
            if (sourceFile != NULL)
            {
                fclose(sourceFile);
                return 0;
            }
            closeFiles(sourceFile, tragetFile);
            return 0;
        }
        else
        {
            if ((argv[FLAG_INDEX])[E_OR_I_INDEX] == E)
            {
                return readAndPrintEncoded(sourceFile, tragetFile);
            }
            else
            {
                return readAndPrintInvertedByMap(sourceFile, tragetFile, invertLetter);
            }
            closeFiles(sourceFile, tragetFile);
        }
    }
    return 0;
}

/**
 * @brief read from the source file an image and
 * print it RLEList-encoded into the traget file
 *
 * @param sourceFile pointer to FILE object to read from
 * @param tragetFile pointer to FILE object to print into
 * @return int 0
 */
int readAndPrintEncoded(FILE *sourceFile, FILE *tragetFile)
{
    RLEList listedImage = asciiArtRead(sourceFile);
    if (listedImage == NULL)
    {
        closeFiles(sourceFile, tragetFile);
        return 0;
    }
    asciiArtPrintEncoded(listedImage, tragetFile);
    RLEListDestroy(listedImage);
    closeFiles(sourceFile, tragetFile);
    return 0;
}

/**
 * @brief read from the source file an image and
 * print it inverted by the map function into the traget file
 *
 * @param sourceFile pointer to FILE object to read from
 * @param tragetFile pointer to FILE object to print into
 * @param map_Function mapping function to invert the source image
 * @return int 0
 */
int readAndPrintInvertedByMap(FILE *sourceFile, FILE *tragetFile, MapFunction map_Function)
{
    RLEListResult result;
    RLEList listedImage = asciiArtRead(sourceFile);
    if (listedImage == NULL)
    {
        closeFiles(sourceFile, tragetFile);
        return 0;
    }
    result = RLEListMap(listedImage, map_Function);
    if (result != RLE_LIST_SUCCESS)
    {
        RLEListDestroy(listedImage);
        closeFiles(sourceFile, tragetFile);
        return 0;
    }
    asciiArtPrint(listedImage, tragetFile);
    RLEListDestroy(listedImage);
    return 0;
}

/**
 * @brief gets char c, if it is '@' it'll be changed to ' ', if it is ' ' it'll be changed to ' ',
 * else it would return c without changes
 *
 * @param c char to invert
 * @return char
 */
char invertLetter(char c)
{
    if (c == CHAR_SPACE)
    {
        return CHAR_STRUDEL;
    }
    if (c == CHAR_STRUDEL)
    {
        return CHAR_SPACE;
    }
    return c;
}

/**
 * @brief close the files streams
 *
 * @param file1 pointer to FILE object
 * @param file2 pointer to FILE object
 */
void closeFiles(FILE *file1, FILE *file2)
{
    fclose(file1);
    fclose(file2);
}
